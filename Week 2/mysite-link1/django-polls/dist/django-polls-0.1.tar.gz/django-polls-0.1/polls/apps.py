from django.apps import AppConfig


class PollsConfig(AppConfig):
    name = 'django-polls.polls'
